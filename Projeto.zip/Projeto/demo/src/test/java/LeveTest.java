import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import com.example.Tanques.Leve;

public class LeveTest {

    @Test
    public void testVelocidadeMedio() {
        Leve leve = new Leve("Rápido", 1,false);
        assertTrue(leve.getVelocidade() == 10);
    }
}