import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import com.example.Gerenciar.Gerenciar;
import com.example.Tanques.Tanque;
import com.example.Tanques.Leve;
import com.example.Tanques.Medio;
import com.example.Tanques.Pesado;

public class GerenciarTest {

    @Test
    public void geracaoInimigos() {
        Gerenciar gerenciar = new Gerenciar();
        gerenciar.geracaoInimigos(10);
        assertEquals(10, gerenciar.getInimigosSize());
    }

    @Test
    public void cadastroTanqueAliado() {
        Gerenciar gerenciar = new Gerenciar();
        Tanque tanque = new Tanque("la ele", 123,false);
        gerenciar.cadastroTanqueAliado(tanque);
        assertEquals(1, gerenciar.getAliadosSize());
    }

    @Test
    public void cadastroTanqueInimigo() {
        Gerenciar gerenciar = new Gerenciar();
        Tanque tanque = new Tanque("inimigo", 999,false);
        gerenciar.cadastroTanqueInimigo(tanque);
        assertEquals(1, gerenciar.getInimigosSize());
    }

    @Test
    public void cadastradoPartidaAdicionaAtivos() {
        Gerenciar gerenciar = new Gerenciar();
        Tanque t1 = new Tanque("A", 1,false);
        Tanque t2 = new Tanque("B", 2,false);
        gerenciar.cadastroTanqueAliado(t1);
        gerenciar.cadastroTanqueAliado(t2);
        int[] tanques = {1, 0};
        gerenciar.cadastradoPartida(tanques);
        assertEquals(1, gerenciar.getAtivosSize());
    }

    @Test
    public void cadastradoPartidaNenhumAtivo() {
        Gerenciar gerenciar = new Gerenciar();
        Tanque t1 = new Tanque("A", 1,false);
        gerenciar.cadastroTanqueAliado(t1);
        int[] tanques = {0};
        gerenciar.cadastradoPartida(tanques);
        assertEquals(0, gerenciar.getAtivosSize());
    }

    @Test
    public void geracaoInimigosCriaTiposDiferentes() {
        Gerenciar gerenciar = new Gerenciar();
        gerenciar.geracaoInimigos(5);
        assertTrue(gerenciar.getInimigosSize() > 0);
    }

    @Test
    public void integracaoCadastroEPartida() {
        Gerenciar gerenciar = new Gerenciar();
        Tanque leve = new Leve("leve", 1,false);
        Tanque medio = new Medio("medio", 2,false);
        Tanque pesado = new Pesado("pesado", 3,false);

        gerenciar.cadastroTanqueAliado(leve);
        gerenciar.cadastroTanqueAliado(medio);
        gerenciar.cadastroTanqueAliado(pesado);

        int[] tanques = {1, 1, 0};
        gerenciar.cadastradoPartida(tanques);

        assertEquals(2, gerenciar.getAtivosSize());
    }
}

