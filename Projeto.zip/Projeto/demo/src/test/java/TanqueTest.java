import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import com.example.Tanques.Tanque;

public class TanqueTest {

    @Test
    public void testReceberDanoReduzIntegridade() {
        Tanque tanque = new Tanque("Bravo", 1,false);
        tanque.receberDano(30);
        assertEquals(70, tanque.getIntegridade());
    }

    @Test
    public void testReceberDanoNaoFicaNegativo() {
        Tanque tanque = new Tanque("Delta", 2,false);
        tanque.receberDano(200);
        assertEquals(0, tanque.getIntegridade());
    }
}