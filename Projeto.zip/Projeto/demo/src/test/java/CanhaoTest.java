import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import com.example.Modulos.Canhao;

public class CanhaoTest {

    @Test
    public void testDanoComMunicao1() {
        Canhao canhao = new Canhao(1);
        assertEquals(8, canhao.dano());
    }

    @Test
    public void testDanoComMunicao2() {
        Canhao canhao = new Canhao(2);
        assertEquals(10, canhao.dano());
    }

    @Test
    public void testDanoComMunicao3() {
        Canhao canhao = new Canhao(3);
        assertEquals(13, canhao.dano());
    }
}