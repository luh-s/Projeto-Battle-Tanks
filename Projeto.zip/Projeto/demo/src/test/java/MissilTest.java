import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import com.example.Modulos.Missil;

public class MissilTest {

    @Test
    public void testDanoRetornaValorPositivo() {
        Missil missil = new Missil(2);
        double dano = missil.dano();
        assertTrue(dano == 14);
    }
}