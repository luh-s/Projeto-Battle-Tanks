import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import com.example.Modulos.Metralhadora;

public class MetralhadoraTeste {

    @Test
    public void testDanoRetornaValorPositivo() {
        Metralhadora metralhadora = new Metralhadora(1);
        double dano = metralhadora.dano();
        assertTrue(dano == 12);
    }
}