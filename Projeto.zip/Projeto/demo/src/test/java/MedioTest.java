import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import com.example.Tanques.Medio;

public class MedioTest {

    @Test
    public void testBlindagemMedio() {
        Medio medio = new Medio("Médio", 2,false);
        assertTrue(medio.getBlindagem()==30);
    }
}