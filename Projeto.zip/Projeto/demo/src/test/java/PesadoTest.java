import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import com.example.Tanques.Pesado;

public class PesadoTest {

    @Test
    public void testBlindagemPesado() {
        Pesado pesado = new Pesado("Tanque Pesado", 3,false);
        assertTrue(pesado.getBlindagem() == 38);
    }
}
