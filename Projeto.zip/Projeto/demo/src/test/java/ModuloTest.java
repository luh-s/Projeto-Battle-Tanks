import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import com.example.Modulos.Modulo;

public class ModuloTest {

    @Test
    public void testSetGetMunicao() {
        Modulo modulo = new Modulo(5);
        assertEquals(5, modulo.getMunicao());
    }

    @Test
    public void testDanoBaseInicialmenteZero() {
        Modulo modulo = new Modulo(1);
        assertEquals(0, modulo.getDanoBase());
    }
}