package com.example.Modulos;

public class Modulo {
    private int danoBase,tempoRecarga,alcanceEficaz,municao;

    //Inicio Get and Set Modulo//
    //=========================//
    public Modulo(int municao) {
        this.municao = municao;
    }
    public int getDanoBase() {
        return danoBase;
    }
    public void setDanoBase(int danoBase) {
        this.danoBase = danoBase;
    }
    public int getTempoRecarga() {
        return tempoRecarga;
    }
    public void setTempoRecarga(int tempoRecarga) {
        this.tempoRecarga = tempoRecarga;
    }
    public int getAlcanceEficaz() {
        return alcanceEficaz;
    }
    public void setAlcanceEficaz(int alcanceEficaz) {
        this.alcanceEficaz = alcanceEficaz;
    }
    public int getMunicao() {
        return municao;
    }
    public void setMunicao(int municao) {
        this.municao = municao;
    }
    //Fim Get and Set Modulo//
    //======================//
    
    public double dano(){
        return 0;
    }
}
 