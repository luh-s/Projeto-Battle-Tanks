package com.example;
import com.example.Gerenciar.*;

import java.util.Random;
import java.util.Scanner;
import com.example.Tanques.*;

public class Main {
    public static void main(String[] args) throws InterruptedException{
        Scanner sc = new Scanner(System.in);
        Gerenciar gerenciar = new Gerenciar();
        Random rd = new Random();
        int escolha=0,moduloEscolha=0,municao=0;
        int id=25070010;
        int[] tanquesEscolha = new int[12];
        String codinome;
        int escolhaHumano;
        boolean humano,rodadaPlayer,agenda=false;
        int segundos=0;
        
        do {

            //Tela Inicial//
            //============//
            gerenciar.clearScreen();
            System.out.printf("\n\t");
            System.out.println("    ___    ____  _______   _____       ____  ___  ______________    ______   _________    _   ____ _______\r\n\t" + //
                                "   /   |  / __ \\/ ____/ | / /   |     / __ )/   |/_  __/_  __/ /   / ____/  /_  __/   |  / | / / //_/ ___/\r\n\t" + //
                                "  / /| | / /_/ / __/ /  |/ / /| |    / __  / /| | / /   / / / /   / __/      / / / /| | /  |/ / ,<  \\__ \\ \r\n\t" + //
                                " / ___ |/ _, _/ /___/ /|  / ___ |   / /_/ / ___ |/ /   / / / /___/ /___     / / / ___ |/ /|  / /| |___/ / \r\n\t" + //
                                "/_/  |_/_/ |_/_____/_/ |_/_/  |_|  /_____/_/  |_/_/   /_/ /_____/_____/    /_/ /_/  |_/_/ |_/_/ |_/____/  \r\n\t" + //
                                "==========================================================================================================");
            System.out.println("\n\n\t\t\t1 - JOGAR\t2 - INFORMAÇÕES\t\t3 - SAIR");
            System.out.printf("\n\t\t\t\tEscolha uma das opções: ");
            escolha=sc.nextInt();

            
            switch (escolha) {


                //Inicio Menu jogo//
                //================//
                case 1:
                    gerenciar.clearScreen();
                    do {
                        gerenciar.clearScreen();
                        System.out.println("\n\n\t\t[=-= BASE DE OPERAÇÕES =-=]\n\n\t1 - Alistar novo tanque (MAX 12)\n\t2 - Escolher Batalha\n\t3 - Listar Tanques Aliados\n\t4 - Agendar\n\t5 - Sair");
                        escolha=sc.nextInt();
                        sc.nextLine();
                        switch (escolha) {
                            case 1:

                                //Limitando a 12 tanques//
                                //======================//
                                if (gerenciar.getAliadosSize()>=12) {
                                    gerenciar.clearScreen();
                                    System.out.println("Máximo de tanques simultaneos atingidos");
                                    Thread.sleep(1000);
                                    break;
                                }
                                do {

                                    //Inicio Cadastro Tanque//
                                    //======================//
                                    gerenciar.clearScreen();
                                    System.out.printf("Digite o codinome do tanque: ");
                                    codinome=sc.nextLine();

                                    //Definição Classe Tanque//
                                    //=======================//
                                    do {
                                        gerenciar.clearScreen();
                                        System.out.printf("\n\n\tQual classe do tanque?\n\n1 - Leve\n2 - Médio\n3 - Pesado");
                                        System.out.printf("\n\t");
                                        escolha=sc.nextInt();

                                        if (escolha<=0||escolha>3) {
                                            System.out.println("Opção ínvalida!");
                                            Thread.sleep(1000);
                                        }

                                    } while (escolha<=0||escolha>3);

                                    //Definição Módulo//
                                    //================//
                                    do {
                                        gerenciar.clearScreen();
                                        System.out.printf("\n\n\tQual módulo do tanque?\n\n1 - Canhão\n2 - Metralhadora\n3 - Míssil");
                                        System.out.printf("\n\t");
                                        moduloEscolha=sc.nextInt();

                                        if (moduloEscolha<=0||moduloEscolha>3) {
                                            System.out.println("Opção ínvalida!");
                                            Thread.sleep(1000);
                                        }

                                    } while (moduloEscolha<=0||moduloEscolha>3);

                                    //Definição Munição//
                                    //=================//
                                    do {
                                        gerenciar.clearScreen();
                                        System.out.printf("\n\n\tQual tipo de munição do tanque?\n\n1 - Perfurante\n2 - Explosiva\n3 - Fragmentação");
                                        System.out.printf("\n\t");
                                        municao=sc.nextInt();

                                        if (municao<=0||municao>3) {
                                            System.out.println("OPÇÃO INVÁLIDA!");
                                            Thread.sleep(1000);
                                        }
                                    
                                    //Humano ou IA//
                                    //============//
                                    } while (municao<=0||municao>3);

                                    do {
                                        gerenciar.clearScreen();
                                        System.out.println("\n\n\tEsse tanque vai ser controlado pelo jogador ou IA?\n\n1 - Humano\n2 - IA");
                                        escolhaHumano=sc.nextInt();
                                        
                                        if (escolhaHumano<=0 || escolhaHumano>2) {
                                            System.out.println("OPÇÃO INVÁLIDA!");
                                            Thread.sleep(1000);
                                        }
                                    } while (escolhaHumano<=0 || escolhaHumano>2);
                                    if (escolhaHumano==1) {
                                        humano=true;
                                    }
                                    else{
                                        humano=false;
                                    }
                                    //Gerenciamento dos Tanques//
                                    //=========================//
                                    if (escolha==1) {
                                        Leve leve = new Leve(codinome,id,humano);
                                        leve.vincularModulo(moduloEscolha, municao);
                                        gerenciar.cadastroTanqueAliado(leve);
                                    }
                                    else if (escolha==2) {
                                        Medio medio = new Medio(codinome,id,humano);
                                        medio.vincularModulo(moduloEscolha, municao);
                                        gerenciar.cadastroTanqueAliado(medio);
                                    }
                                    else{
                                        Pesado pesado = new Pesado(codinome,id,humano);
                                        pesado.vincularModulo(moduloEscolha, municao);
                                        gerenciar.cadastroTanqueAliado(pesado);
                                    }
                                    id++;
                                    escolha=1;


                                } while (escolha!=1);
                                break;
                                //Fim Cadastro Tanque//
                                //===================//


                            //Inicio dos Modos de Batalha//
                            //===========================//
                            case 2:
                                gerenciar.clearScreen();
                                System.out.println("\n\t\t[=-= MODOS DE BATALHA =-=]\n\n\t1 - TREINO (VOCÊ NÃO PERDE SEUS TANQUES)\n\t2 - 1v1 \n\t3 - 3v3\n\t4 - Sair");
                                escolha=sc.nextInt();
                                
                                switch (escolha) {
                                    case 1:
                                        gerenciar.clearScreen();
                                        if (gerenciar.getAliadosSize()==0) {
                                            System.out.println("Sem tanques disponíveis para lutar!");
                                            Thread.sleep(1000);
                                            break;
                                        }
                                        else if (gerenciar.getAliadosSize()>=1) {
                                            do {
                                                gerenciar.clearScreen();
                                                System.out.println("Escolha qual tanque deseja jogar?");
                                                gerenciar.listarTanques(1);
                                                System.out.printf("\nDigite o número do tanque e confirme: ");
                                                escolha=sc.nextInt();

                                                if (escolha<=0||escolha>12) {
                                                    System.out.println("OPÇÃO INVÁLIDA!");
                                                }
                                                else{
                                                    tanquesEscolha[escolha-1]=1;
                                                    gerenciar.cadastradoPartida(tanquesEscolha);
                                                }
                                            } while (escolha<=0||escolha>12);

                                            if (agenda==true) {
                                                int tempo=segundos;
                                                for (int i = 0; i < segundos; i++) {
                                                    gerenciar.clearScreen();
                                                    System.out.println(tempo+" segundos para começar a batalha!");
                                                    Thread.sleep(1000);
                                                    if (i==segundos) {
                                                        System.out.println("Tempo de espera acabou!");
                                                    }
                                                    else{
                                                        tempo--;
                                                    }
                                                }
                                                agenda=false;
                                                segundos=0;
                                                tempo=0;
                                            }
                                            rodadaPlayer=true;
                                            gerenciar.geracaoInimigos(1);
                                            gerenciar.clearScreen();
                                            switch (rd.nextInt(3)) {
                                                case 0:
                                                    System.out.println("\n\t[=-= Em meio ao deserto, uma batalha entre tanques começa! =-=]");
                                                    break;
                                                case 1:
                                                    System.out.println("\n\t[=-= Em meio ao um grande campo, uma batalha entre tanques começa! =-=]");
                                                    break;
                                                case 2:
                                                    System.out.println("\n\t[=-= Em meio a uma grande floresta, uma batalha entre tanques começa! =-=]");
                                                    break;
                                            }
                                            Thread.sleep(2000);
                                            do {
                                                gerenciar.clearScreen();
                                                gerenciar.partida(rodadaPlayer);
                                                if (rodadaPlayer==true) {
                                                    rodadaPlayer=false;
                                                }
                                                else{
                                                    rodadaPlayer=true;
                                                }
                                            } while (gerenciar.verificarPartida(true)==true);
                                            gerenciar.exportarRelatorioCSV("demo/csv/relatorio_batalha.csv");
                                            tanquesEscolha[escolha-1]=0;
                                        }
                                        break;
                                    case 2:
                                        gerenciar.clearScreen();
                                        if (gerenciar.getAliadosSize()==0) {
                                            System.out.println("Sem tanques disponíveis para lutar!");
                                            Thread.sleep(1000);
                                            break;
                                        }
                                        else if (gerenciar.getAliadosSize()>=1) {
                                            do {
                                                gerenciar.clearScreen();
                                                System.out.println("Escolha qual tanque deseja jogar?");
                                                gerenciar.listarTanques(1);
                                                System.out.printf("\nDigite o número do tanque e confirme: ");
                                                escolha=sc.nextInt();

                                                if (escolha<=0||escolha>12) {
                                                    System.out.println("OPÇÃO INVÁLIDA!");
                                                }
                                                else{
                                                    tanquesEscolha[escolha-1]=1;
                                                    gerenciar.cadastradoPartida(tanquesEscolha);
                                                }
                                            } while (escolha<=0||escolha>12);
                                            if (agenda==true) {
                                                int tempo=segundos;
                                                for (int i = 0; i < segundos; i++) {
                                                    gerenciar.clearScreen();
                                                    System.out.println(tempo+" segundos para começar a batalha!");
                                                    Thread.sleep(1000);
                                                    if (i==segundos) {
                                                        System.out.println("Tempo de espera acabou!");
                                                    }
                                                    else{
                                                        tempo--;
                                                    }
                                                }
                                                agenda=false;
                                                segundos=0;
                                                tempo=0;
                                            }
                                            rodadaPlayer=true;
                                            gerenciar.geracaoInimigos(1);
                                            gerenciar.clearScreen();
                                            switch (rd.nextInt(3)) {
                                                case 0:
                                                    System.out.println("\n\t[=-= Em meio ao deserto, uma batalha entre tanques começa! =-=]");
                                                    break;
                                                case 1:
                                                    System.out.println("\n\t[=-= Em meio ao um grande campo, uma batalha entre tanques começa! =-=]");
                                                    break;
                                                case 2:
                                                    System.out.println("\n\t[=-= Em meio a uma grande floresta, uma batalha entre tanques começa! =-=]");
                                                    break;
                                            }
                                            Thread.sleep(2000);
                                        do {
                                            gerenciar.clearScreen();
                                                gerenciar.partida(rodadaPlayer);
                                                if (rodadaPlayer==true) {
                                                    rodadaPlayer=false;
                                                }
                                                else{
                                                    rodadaPlayer=true;
                                                }
                                        } while (gerenciar.verificarPartida(false)==true);
                                        gerenciar.exportarRelatorioCSV("demo/csv/relatorio_batalha.csv");
                                        tanquesEscolha[escolha-1]=0;
                                        }
                                        break;
                                    case 3:
                                        gerenciar.clearScreen();
                                            if (gerenciar.getAliadosSize()<3) {
                                                System.out.println("Sem tanques disponíveis para lutar!");
                                                Thread.sleep(1000);
                                                break;
                                            }
                                            else if (gerenciar.getAliadosSize()>=3) {
                                                for (int i = 0; i < 3; i++) {
                                                    gerenciar.clearScreen();
                                                    System.out.println("Escolha qual tanque deseja jogar?");
                                                    gerenciar.listarTanques(1);
                                                    System.out.printf("\nDigite o número do tanque e confirme: ");
                                                    escolha=sc.nextInt();
                                                    
                                                    if (escolha<=0||escolha>12) {
                                                    System.out.println("OPÇÃO INVÁLIDA!");
                                                    }
                                                    else{
                                                        tanquesEscolha[escolha-1]=1;
                                                        
                                                    }
                                                }
                                                gerenciar.cadastradoPartida(tanquesEscolha);
                                            }
                                            if (agenda==true) {
                                                int tempo=segundos;
                                                for (int i = 0; i < segundos; i++) {
                                                    gerenciar.clearScreen();
                                                    System.out.println(tempo+" segundos para começar a batalha!");
                                                    Thread.sleep(1000);
                                                    if (i==segundos) {
                                                        System.out.println("Tempo de espera acabou!");
                                                    }
                                                    else{
                                                        tempo--;
                                                    }
                                                }
                                                agenda=false;
                                                segundos=0;
                                                tempo=0;
                                                }
                                                rodadaPlayer=true;
                                                gerenciar.geracaoInimigos(3);
                                                gerenciar.clearScreen();
                                                switch (rd.nextInt(3)) {
                                                    case 0:
                                                        System.out.println("\n\t[=-= Em meio ao deserto, uma batalha entre tanques começa! =-=]");
                                                        break;
                                                    case 1:
                                                        System.out.println("\n\t[=-= Em meio ao um grande campo, uma batalha entre tanques começa! =-=]");
                                                        break;
                                                    case 2:
                                                        System.out.println("\n\t[=-= Em meio a uma grande floresta, uma batalha entre tanques começa! =-=]");
                                                        break;
                                                }
                                                Thread.sleep(2000);
                                            do {
                                                gerenciar.clearScreen();
                                                    gerenciar.partida(rodadaPlayer);
                                                    if (rodadaPlayer==true) {
                                                        rodadaPlayer=false;
                                                    }
                                                    else{
                                                        rodadaPlayer=true;
                                                    }
                                            } while (gerenciar.verificarPartida(false)==true);
                                            gerenciar.exportarRelatorioCSV("demo/csv/relatorio_batalha.csv");
                                            for (int i = 0; i < tanquesEscolha.length; i++) {
                                                tanquesEscolha[i]=0;
                                            }
                                }
                                break;
                                //Fim dos Modos de Batalha//
                                //========================//
                                
                            
                            //Inicio Listagem dos Tanques Cadastrados//
                            //=======================================//
                            case 3:
                                gerenciar.clearScreen();
                                if (gerenciar.getAliadosSize()==0) {
                                    System.out.println("\n\t[=-= Sem tanques cadastrados! =-=]");
                                    Thread.sleep(1500);
                                    break;
                                }
                                System.out.println("\n\t\t[=-= TANQUES ALIADOS =-=]\n");
                                gerenciar.listarTanques(1);
                                System.out.println("\n\n\t[=-= Digite qualquer coisa e aperte Enter para voltar ao menu =-=]");
                                sc.next();
                                break;
                                //Fim Listagem dos Tanques Cadastrados//
                                //====================================//


                            case 4:
                                System.out.println("Quanto tempo deseja? (Em segundos)");
                                segundos=sc.nextInt();
                                System.out.println("Escolha um modo de batalha e o tempo agendado irar começar.");
                                agenda=true;
                                Thread.sleep(1500);
                                break;

                            case 5:
                                escolha=5;
                                break;

                            default:
                                gerenciar.clearScreen();
                                System.out.println("\n\tOPÇÃO INVÁLIDA!");
                                Thread.sleep(1000);
                                escolha=1;
                                break;
                        }
                    } while (escolha!=5);
                    break;
                    //Fim Menu Jogo//
                    //=============//


                //Tela de Informações//
                //===================//
                case 2:
                    gerenciar.clearScreen();
                    System.out.println("\t\t\t\t[=-= INFORMAÇÕES =-=]\n\n\tArena Battle Tanks é um projeto avaliativo da matéria de Programação Orientada a Objetos.\n\n\tTem como objetivo aprimorar as habilidades técnicas dos alunos orientados pelo professor Isaac Souza Elgrably.\n\n\tProjeto realizado pelo aluno Luan Piedade de Oliveira do CENTRO UNIVERSITÁRIO DO ESTADO DO PARÁ\n\n\t\t[=-= Digite qualquer coisa e aperte Enter para voltar ao menu =-=]");
                    sc.next();
                    break;


                //Sair do Programa//
                //================//
                case 3:
                    gerenciar.clearScreen();
                    System.out.println("\n\t\tOBRIGADO POR JOGAR!\n\n");
                    
                    break;


                //Tela Erro//
                //=========//
                default:
                    System.out.println("\n\n\t\t\t\t==-= !OPÇÃO INVÁLIDA! =-=");
                    Thread.sleep(1000);
                    break;
            }
        } while (escolha!=3);
        sc.close();
    }
    
}