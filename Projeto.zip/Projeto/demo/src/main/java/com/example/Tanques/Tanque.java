package com.example.Tanques;
import java.util.Random;

import com.example.Modulos.*;

public class Tanque{
    Random rd = new Random();
    private int modulo,municao,id,rodadasRestantes;
    private Metralhadora metralhadora;private Canhao canhao;private Missil missil;
    private String codinome;
    private double blindagem,velocidade,podeDeFogo;
    private boolean humano;
    private double integridade=100;

    

    public Tanque() {
    }

    public Tanque(String codinome,int id,boolean humano) {
        this.codinome = codinome;
        this.id = id;
        this.humano = humano;
    }
    //
    //

    
    public void receberDano(double dano) {
        integridade -= dano;
        if (integridade < 0) integridade = 0;
    }

    //Inicio Get and Set Tanque//
    //=========================//
    public int getModulo() {
        return modulo;
    }
    public double getIntegridade() {
        return integridade;
    }

    public void setIntegridade(double integridade) {
        this.integridade = integridade;
    }

    public Metralhadora getMetralhadora() {
        return metralhadora;
    }
    public void setMetralhadora(Metralhadora metralhadora) {
        this.metralhadora = metralhadora;
    }
    public Canhao getCanhao() {
        return canhao;
    }
    public void setCanhao(Canhao canhao) {
        this.canhao = canhao;
    }
    public Missil getMissil() {
        return missil;
    }
    public void setMissil(Missil missil) {
        this.missil = missil;
    }
    public void setVelocidade(double velocidade) {
        this.velocidade = velocidade;
    }
    public void setPodeDeFogo(double podeDeFogo) {
        this.podeDeFogo = podeDeFogo;
    }
    public void setModulo(int modulo) {
        this.modulo = modulo;
    }
    public String getCodinome() {
        return codinome;
    }
    public void setCodinome(String codinome) {
        this.codinome = codinome;
    }
    public double getBlindagem() {
        return blindagem;
    }
    public void setBlindagem(double blindagem) {
        this.blindagem = blindagem;
    }
    public double getVelocidade() {
        return velocidade;
    }
    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }
    public double getPodeDeFogo() {
        return podeDeFogo;
    }
    public int getId() {
        return id;
    }
    //Fim Get and Set Tanque//
    //======================//



    //Inicio Verificação CAPTCHA//
    //==========================//
    public boolean isHumano() {
        return humano;
    }
    public void setHumano(boolean humano) {
        humano = humano;
    }
    public int getMunicao() {
        return municao;
    }
    public void setMunicao(int municao) {
        this.municao = municao;
    }
    //Fim Verificação CAPTCHA//
    //=======================//



    //Inicio Vinculação Módulo//
    //========================//
    public void vincularCanhao(Canhao canhao){
        this.canhao = canhao;
    }
    public void vincularMetralhadora(Metralhadora metralhadora){
        this.metralhadora = metralhadora;
    }
    public void vincularMissil(Missil missil){
        this.missil = missil;
    }

    public void vincularModulo(int modulo,int municao){
        this.modulo=modulo;this.municao=municao;
        if (modulo==1) {
            Canhao canhao = new Canhao(municao);
            vincularCanhao(canhao);
        }
        else if (modulo==2) {
            Metralhadora metralhadora = new Metralhadora(municao);
            vincularMetralhadora(metralhadora);
        }
        else{
            Missil missil = new Missil(municao);
            vincularMissil(missil);
        }
    }
    //Fim Vinculação Módulo//
    //=====================//


    //Inicio Métodos Abstratos//
    //========================//
    public void listarTanque(){
    }
    //Fim Métodos Abstratos//
    //=====================//
}
