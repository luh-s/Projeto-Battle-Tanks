package com.example.Modulos;

public class Missil extends Modulo{

    public Missil(int municao) {
        super(municao);
        setDanoBase(4);
        setTempoRecarga(7);
        setAlcanceEficaz(4);
    }

    @Override
    public double dano(){
        double dano=0;
        switch (super.getMunicao()) {
            case 1:
                dano=super.getDanoBase()+5;
                break;
            case 2:
                dano=super.getDanoBase()+10;
                break;
            case 3:
                dano=super.getDanoBase()+7;
                break;
        }
        return dano;
    }
}
