package com.example.Tanques;

public class Pesado extends Tanque{

    public Pesado(String codinome,int id,boolean humano) {
        super(codinome,id,humano);
        setBlindagem(38);
        setVelocidade(5);
        setPodeDeFogo(10);
    }

    @Override
    public void listarTanque(){
        System.out.printf("Id: "+super.getId()+" | Codinome: "+super.getCodinome()+" | ");
        System.out.printf("Classe: Pesado | ");
        switch (super.getModulo()) {
            case 1:
                System.out.printf("Módulo: Canhão | ");
                break;
            case 2:
                System.out.printf("Módulo: Metralhadora | ");
                break;
            case 3:
                System.out.printf("Módulo: Míssil | ");
                break;

        }
        switch (super.getMunicao()) {
            case 1:
                System.out.printf("Munição: Perfurante");
                break;
            case 2:
                System.out.printf("Munição: Explosiva");
                break;
            case 3:
                System.out.printf("Munição: Fragmentação");
                break;
        }
        System.out.print(" | Integridade: "+getIntegridade());
    }
}
