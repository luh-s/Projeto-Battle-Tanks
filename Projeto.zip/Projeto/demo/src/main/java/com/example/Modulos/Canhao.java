package com.example.Modulos;

public class Canhao extends Modulo{

    public Canhao(int municao) {
        super(municao);
        setDanoBase(1);
        setTempoRecarga(1);
        setAlcanceEficaz(9);
    }

    @Override
    public double dano(){
        double dano=0;
        switch (super.getMunicao()) {
            case 1:
                dano=super.getDanoBase()+3;
                break;
            case 2:
                dano=super.getDanoBase()+5;
                break;
            case 3:
                dano=super.getDanoBase()+8;
                break;
        }
        return dano;
    }
}
