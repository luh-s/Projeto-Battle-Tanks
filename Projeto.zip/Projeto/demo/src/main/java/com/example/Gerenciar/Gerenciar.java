package com.example.Gerenciar;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import com.example.Modulos.*;
import com.example.Tanques.*;

public class Gerenciar {
    ArrayList<Tanque> aliados = new ArrayList<>();
    ArrayList<Tanque> inimigos = new ArrayList<>();
    ArrayList<Tanque> ativos = new ArrayList<>();
    private int idInimigo=24081037;
    private String codinomeInimigo="Tanque Inimigo";


    //Inicio Cadastros//
    //================//
    public void cadastroTanqueAliado(Tanque tanque){
        aliados.add(tanque);
    }
    public void cadastroTanqueInimigo(Tanque tanque){
        inimigos.add(tanque);
    }
    public void cadastradoPartida(int[] tanques){
        int i=0;
        for (Tanque tanque : aliados) {
            if (tanques[i]==1) {
                ativos.add(tanque);
            }
            i++;
        }
    }
    //Fim Cadastros//
    //=============//


    //Inicio Gerando Inimigo Aleatorio//
    //================================//
    public void geracaoInimigos(int quantidade){
        Random rd = new Random();
        int escolhaClasse=rd.nextInt(3);
        int escolhaModulo=rd.nextInt(3)+1;
        int escolhaMunicao=rd.nextInt(3)+1;
        for (int i = 0; i < quantidade; i++) {
            if (escolhaClasse==0) {
                Leve leve = new Leve(codinomeInimigo,idInimigo,false);
                leve.vincularModulo(escolhaModulo, escolhaMunicao);
                cadastroTanqueInimigo(leve);
            }
            else if (escolhaClasse==1) {
                Medio medio = new Medio(codinomeInimigo,idInimigo,false);
                medio.vincularModulo(escolhaModulo, escolhaMunicao);
                cadastroTanqueInimigo(medio);
            }
            else if(escolhaClasse==2){
                Pesado pesado = new Pesado(codinomeInimigo,idInimigo,false);
                pesado.vincularModulo(escolhaModulo, escolhaMunicao);
                cadastroTanqueInimigo(pesado);
            }
        }
        idInimigo++;
    }
    //Fim Gerando Inimigos Aleatorios//
    //===============================//


    public int getAliadosSize(){
        return aliados.size();
    }
    public int getInimigosSize(){
        return inimigos.size();
    }
    public int getAtivosSize(){
        return ativos.size();
    }
    public void listarTanques(int array){
        if (array==1) {
            int i=1;
            for (Tanque tanque : aliados) {
                System.out.printf(i+": // ");tanque.listarTanque();System.out.print(" \\\\");
                System.out.println();
                i++;
            }
        }
        else if (array==2){
            int i=1;
            for (Tanque tanque : inimigos) {
                System.out.printf(i+": // ");tanque.listarTanque();System.out.print(" \\\\");
                System.out.println();
                i++;
            }
        }
        else if (array==3) {
            int i=1;
            for (Tanque tanque : ativos) {
                System.out.printf(i+": // ");tanque.listarTanque();System.out.print(" \\\\");
                System.out.println();
                i++;
            }
        }
        
    }


    //Inicio Código para "Limpar" o Terminal//
    //======================================//
    public void clearScreen() {  
    System.out.print("\033[H\033[2J");
    System.out.flush();
    }
    //Fim Código para "Limpar" o Terminal//
    //===================================//

    
    //Inicio Verificar se Partida Continua//
    //====================================//
    public boolean verificarPartida(boolean treino) throws InterruptedException{
        int mortos=0,i=0;
        int mortosInimigos=0;
        int vivosTotais=aliados.size();
        int vivosTotaisInimigos=inimigos.size();
        Tanque[] tanquesDestruidos = new Tanque[12];
        for (Tanque tanque : aliados) {
            if (tanque.getIntegridade()<=0) {
                System.out.println("\n\nTanque de codinome "+tanque.getCodinome()+" foi destruido");
                ativos.remove(tanque);
                if (treino==false) {
                    tanquesDestruidos[i]=tanque;
                    i++;
                }
                mortos++;
            }
        }
        for ( i = 0; i < tanquesDestruidos.length; i++) {
            aliados.remove(tanquesDestruidos[i]);
        }

        for (Tanque tanque : inimigos) {
            if (tanque.getIntegridade()<=0) {
                System.out.println("Tanque inimigo abatido!");
                mortosInimigos++;
            }
        }
        if (mortos==vivosTotais) {
            clearScreen();
            System.out.println("\n\tTodos os tanques do batalhão dos aliados foram derrotados!");
            System.out.println("\n\t[=-= Você perdeu! =-=]");
            Thread.sleep(3000);
            ativos.clear();
            return false;
        }
        else if (mortosInimigos==vivosTotaisInimigos) {
            clearScreen();
            System.out.println("\n\tTodos os tanques do batalhão Inimigo foram derrotados!");
            System.out.println("\n\t[=-= Você ganhou! =-=]");
            for (Tanque tanque : aliados) {
                tanque.setIntegridade(100);
            }
            Thread.sleep(3000);
            ativos.clear();
            return false;
        }
        else{
            return true;
        }
    }
    //Fim Verificar se Partida Continua//
    //=================================//


    //Inicio Partida//
    //==============//
    public void partida(boolean rodada) throws InterruptedException{
        Random rd = new Random();
        Scanner sc=new Scanner(System.in);
        int escolha=0;
        int i=0;
        if (rodada==false) {
            for (Tanque tanque : inimigos) {
                System.out.println("\n\tO tanque de codinome: "+tanque.getCodinome()+" começou seu ataque.");
                Thread.sleep(1500);
                int aleatorio=rd.nextInt(10);
                if (aleatorio==9) {
                    System.out.println("\n\t[=-= O tanque inimigo pulou a vez! =-=]");
                    Thread.sleep(2000);
                }
                else{
                    aleatorio=rd.nextInt(getAtivosSize());
                    if (tanque.getModulo()==1) {
                        Canhao canhao =  new Canhao(tanque.getMunicao());
                        i=0;
                        for (Tanque tanque2 : ativos) {
                            if (i==aleatorio) {
                                tanque2.receberDano(canhao.dano());
                                System.out.printf("\n\nTanque codinome: "+tanque.getCodinome()+" disparou com canhão de munição ");
                                if (tanque.getMunicao()==1) {
                                    System.out.printf("perfurante em: "+tanque2.getCodinome());
                                }
                                else if (tanque.getMunicao()==2) {
                                    System.out.printf("explosiva em: "+tanque2.getCodinome());
                                }
                                else{
                                    System.out.printf("fragmentada em: "+tanque2.getCodinome());
                                }
                                Thread.sleep(3000);
                            }
                            i++;
                        }
                    }
                    else if (tanque.getModulo()==2) {
                        Metralhadora metralhadora = new Metralhadora(tanque.getMunicao());
                        i=0;
                        for (Tanque tanque2 : ativos) {
                            if (i==aleatorio) {
                                tanque2.receberDano(metralhadora.dano());
                                System.out.printf("\n\nTanque de codinome: "+tanque.getCodinome()+" disparou com canhão de munição ");
                                if (tanque.getMunicao()==1) {
                                    System.out.printf("perfurante em: "+tanque2.getCodinome());
                                }
                                else if (tanque.getMunicao()==2) {
                                    System.out.printf("explosiva em: "+tanque2.getCodinome());
                                }
                                else{
                                    System.out.printf("fragmentada em: "+tanque2.getCodinome());
                                }
                                Thread.sleep(3000);
                            }
                            i++;
                        }
                    }
                    else{
                        Missil missil = new Missil(tanque.getMunicao());
                        i=0;
                        for (Tanque tanque2 : ativos) {
                            if (i==aleatorio) {
                                tanque2.receberDano(missil.dano());
                                System.out.printf("\n\nTanque de codinome: "+tanque.getCodinome()+" disparou com canhão de munição ");
                                if (tanque.getMunicao()==1) {
                                    System.out.printf("perfurante em: "+tanque2.getCodinome());
                                }
                                else if (tanque.getMunicao()==2) {
                                    System.out.printf("explosiva em: "+tanque2.getCodinome());
                                }
                                else{
                                    System.out.printf("fragmentada em: "+tanque2.getCodinome());
                                }
                                Thread.sleep(3000);
                            }
                            i++;
                        }
                    }
                }
            }
        }
        else {
            do {
                for (Tanque tanque : ativos) {
                    if (tanque.isHumano()==true) {
                        do {
                        clearScreen();
                        System.out.println("\n\tO tanque de codinome: "+tanque.getCodinome()+" começou seu ataque.\n\n\t1 - Atacar\t2 - Pular\t3 -Listar atributos");
                        escolha=sc.nextInt();

                        if (escolha<=0||escolha>4) {
                            System.out.println("OPÇÃO INVÁLIDA");
                            Thread.sleep(1000);
                        }
                    } while (escolha<=0||escolha>4);
                    if (escolha==1) {
                        do {
                            do {
                                clearScreen();
                                listarTanques(2);
                                System.out.printf("\nDigite o número do tanque que deseja atacar: \n");
                                escolha=sc.nextInt();
                                

                                if (escolha<=0||escolha>getInimigosSize()) {
                                    System.out.println("OPÇÃO INVÁLIDA");
                                    Thread.sleep(1000);
                                }
                                else{
                                    System.out.println("\n\t[=-= Tanque "+tanque.getCodinome()+" disparou! =-=]");
                                    Thread.sleep(1500);
                                }
                            } while (escolha<=0||escolha>getInimigosSize());
                            
                            if (tanque.getModulo()==1) {
                                Canhao canhao =  new Canhao(tanque.getMunicao());
                                i=0;
                                for (Tanque tanque2 : inimigos) {
                                    if (i==escolha-1) {
                                        tanque2.receberDano(canhao.dano());
                                    }
                                    i++;
                                }
                            }
                            else if (tanque.getModulo()==2){
                                Metralhadora metralhadora = new Metralhadora(tanque.getMunicao());
                                i=0;
                                for (Tanque tanque2 : inimigos) {
                                    if (i==escolha-1) {
                                        tanque2.receberDano(metralhadora.dano());
                                    }
                                    i++;
                                }
                            }
                            else{
                                Missil missil = new Missil(tanque.getMunicao());
                                i=0;
                                for (Tanque tanque2 : inimigos) {
                                    if (i==escolha-1) {
                                        tanque2.receberDano(missil.dano());
                                    }
                                    i++;
                                }
                            }
                        } while (escolha<=0||escolha>inimigos.size());
                    }
                    else if (escolha==2) {
                        System.out.println("\t[=-= Você pulou a vez do tanque! =-=]");
                        Thread.sleep(1000);
                    }
                    else if (escolha==3) {
                        clearScreen();
                        listarTanques(3);
                        System.out.println("\n\n\t[=-= Digite qualquer coisa e aperte Enter para voltar ao menu =-=]");
                        sc.next();
                        escolha=3;
                    }
                    }
                    else{
                        escolha=1;
                        System.out.println("\n\tO tanque de codinome: "+tanque.getCodinome()+" começou seu ataque.");
                        Thread.sleep(1500);
                        int aleatorio=rd.nextInt(10);
                        if (aleatorio==9) {
                            System.out.println("\n\t[=-= O tanque aliado pulou a vez! =-=]");
                            Thread.sleep(2000);
                        }
                        else{
                            aleatorio=rd.nextInt(getInimigosSize());
                            if (tanque.getModulo()==1) {
                                Canhao canhao =  new Canhao(tanque.getMunicao());
                                i=0;
                                for (Tanque tanque2 : inimigos) {
                                    if (i==aleatorio) {
                                        tanque2.receberDano(canhao.dano());
                                        System.out.printf("\n\nTanque codinome: "+tanque.getCodinome()+" disparou com canhão de munição ");
                                        if (tanque.getMunicao()==1) {
                                            System.out.printf("perfurante em: "+tanque2.getCodinome());
                                        }
                                        else if (tanque.getMunicao()==2) {
                                            System.out.printf("explosiva em: "+tanque2.getCodinome());
                                        }
                                        else{
                                            System.out.printf("fragmentada em: "+tanque2.getCodinome());
                                        }
                                        Thread.sleep(3000);
                                    }
                                    i++;
                                }
                            }
                            else if (tanque.getModulo()==2) {
                                Metralhadora metralhadora = new Metralhadora(tanque.getMunicao());
                                i=0;
                                for (Tanque tanque2 : inimigos) {
                                    if (i==aleatorio) {
                                        tanque2.receberDano(metralhadora.dano());
                                        System.out.printf("\n\nTanque de codinome: "+tanque.getCodinome()+" disparou com canhão de munição ");
                                        if (tanque.getMunicao()==1) {
                                            System.out.printf("perfurante em: "+tanque2.getCodinome());
                                        }
                                        else if (tanque.getMunicao()==2) {
                                            System.out.printf("explosiva em: "+tanque2.getCodinome());
                                        }
                                        else{
                                            System.out.printf("fragmentada em: "+tanque2.getCodinome());
                                        }
                                        Thread.sleep(3000);
                                    }
                                    i++;
                                }
                            }
                            else{
                                Missil missil = new Missil(tanque.getMunicao());
                                i=0;
                                for (Tanque tanque2 : inimigos) {
                                    if (i==aleatorio) {
                                        tanque2.receberDano(missil.dano());
                                        System.out.printf("\n\nTanque de codinome: "+tanque.getCodinome()+" disparou com canhão de munição ");
                                        if (tanque.getMunicao()==1) {
                                            System.out.printf("perfurante em: "+tanque2.getCodinome());
                                        }
                                        else if (tanque.getMunicao()==2) {
                                            System.out.printf("explosiva em: "+tanque2.getCodinome());
                                        }
                                        else{
                                            System.out.printf("fragmentada em: "+tanque2.getCodinome());
                                        }
                                        Thread.sleep(3000);
                                    }
                                    i++;
                                }
                            }
                        }
                    }
                    
                }
            } while (escolha!=1&&escolha!=2);
        }
    }

    public void exportarRelatorioCSV(String caminhoArquivo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(caminhoArquivo))) {
            writer.println("id,codinome,integridade,tipo");

            for (Tanque aliado : aliados) {
                writer.printf("%d,%s,%.2f,Aliado%n", 
                    aliado.getId(), aliado.getCodinome(), aliado.getIntegridade());
            }

            for (Tanque inimigo : inimigos) {
                writer.printf("%d,%s,%.2f,Inimigo%n", 
                    inimigo.getId(), inimigo.getCodinome(), inimigo.getIntegridade());
            }

            System.out.println("Relatório CSV gerado em: " + caminhoArquivo);
        } catch (IOException e) {
            System.err.println("Erro ao gerar CSV: " + e.getMessage());
        }
    }
}
